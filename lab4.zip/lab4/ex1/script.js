// 1. Selectăm elementele din DOM
const inputActivitate = document.getElementById("inputActivitate");
const btnAdauga = document.getElementById("btnAdauga");
const listaActivitati = document.getElementById("listaActivitati");

// 2. Definim tabloul cu lunile anului în limba română
const lunileAnului = [
    "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
    "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];

// 3. Funcția care adaugă activitatea
function adaugaActivitate() {
    // Citim textul introdus
    const textActivitate = inputActivitate.value.trim();

    // Verificăm dacă textul nu este gol
    if (textActivitate !== "") {
        
        // Creăm un nou element de listă <li>
        const elementNou = document.createElement("li");

        // Obținem data curentă
        const dataCurenta = new Date();
        const ziua = dataCurenta.getDate();
        const lunaIndex = dataCurenta.getMonth(); // Returnează index de la 0 la 11
        const anul = dataCurenta.getFullYear();

        // Extragem numele lunii din tablou
        const numeLuna = lunileAnului[lunaIndex];

        // Construim textul final
        // Format: Activitate – adăugată la: 16 Noiembrie 2025
        const textFinal = `${textActivitate} – adăugată la: ${ziua} ${numeLuna} ${anul}`;

        // Setăm textul elementului li
        elementNou.textContent = textFinal;

        // Adăugăm elementul în lista ul
        listaActivitati.appendChild(elementNou);

        // Golim câmpul de input după adăugare
        inputActivitate.value = "";
    } else {
        alert("Te rog să introduci o activitate înainte de a apăsa butonul.");
    }
}

// 4. Atașăm evenimentul de click pe buton
btnAdauga.addEventListener("click", adaugaActivitate);