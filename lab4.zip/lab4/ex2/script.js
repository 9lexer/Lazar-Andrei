// 1. Selectăm elementele necesare
const btnDetalii = document.getElementById("btnDetalii");
const divDetalii = document.getElementById("detalii");
const spanData = document.getElementById("dataProdus");

// 2. Tabloul cu lunile anului (pentru data în format text)
const lunileAnului = [
    "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
    "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];

// 3. Funcționalitate executată la "încărcarea paginii" (executare imediată)
function initializarePagina() {
    // A. Ascundem secțiunea de detalii adăugând clasa .ascuns
    divDetalii.classList.add("ascuns");

    // B. Calculăm și afișăm data curentă
    const dataAzi = new Date();
    const ziua = dataAzi.getDate();
    const luna = lunileAnului[dataAzi.getMonth()];
    const anul = dataAzi.getFullYear();

    // Format: 16 Noiembrie 2025
    spanData.textContent = `${ziua} ${luna} ${anul}`;
}

// Apelăm funcția de inițializare
initializarePagina();

// 4. Funcționalitate la click pe buton
btnDetalii.addEventListener("click", function() {
    
    // A. Comutăm vizibilitatea (adăugăm/scoatem clasa .ascuns)
    divDetalii.classList.toggle("ascuns");

    // B. Modificăm textul butonului în funcție de stare
    // Verificăm dacă div-ul are clasa 'ascuns' DUPĂ toggle
    if (divDetalii.classList.contains("ascuns")) {
        // Dacă e ascuns, butonul trebuie să zică "Afișează"
        btnDetalii.textContent = "Afișează detalii";
    } else {
        // Dacă e vizibil, butonul trebuie să zică "Ascunde"
        btnDetalii.textContent = "Ascunde detalii";
    }
});